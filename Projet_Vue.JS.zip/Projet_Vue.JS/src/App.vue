<template>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button type="button" class="btn btn-none" style="border: 1px solid;"> <strong>HUMAINS OF<br>NEW YORK</strong></button>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText" style="padding-left: 700px">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <button type="button" class="btn btn-none"><strong> STORIES .</strong></button>
        </li>
        <li class="nav-item">
          <button type="button" class="btn btn-none"><strong> COUNTRIES .</strong></button>
        </li>
        <li class="nav-item">
          <button type="button" class="btn btn-none"><strong> SERIES .</strong></button>
        </li>
        <li class="nav-item">
          <button type="button" class="btn btn-none"><strong> SHARE </strong></button>
        </li>
      </ul>
      
    </div>
  </div>
</nav> <br><br>
<div>
  <div class="text">
    <h3>HUMANS OF NEW YORK</h3>
    <h1 style="font-size: 100px;">Series</h1>
    <p style="font-size: 20px;">These stories focus on specific populations, examining<br> their experiences and the challenges that they face.</p>
  </div>
  <div class="first">
    <h3>HUMANS OF NEW YORK</h3>
    <h1 class="first1">Invisible<br>Wounds</h1>
    <button type="submit" class="btn btn-none" style="margin-right: 100px;">READ SERIES</button>
  </div>
  <div class="two">
    <h3>HUMANS OF NEW YORK</h3>
    <h1 class="two2">Pediatric<br>Cancer</h1>
    <button type="button" class="btn btn-none" style="margin-left: 100px;">READ SERIES</button>
  </div>
  <div class="free">
    <h3>HUMANS OF NEW YORK</h3>
    <h1 class="free3">Inmate<br>Stories</h1>
    <button type="submit" class="btn btn-none" style="margin-right: 100px;">READ SERIES</button>
  </div>
  <div class="four">
    <h3>HUMANS OF NEW YORK</h3>
    <h1 class="four4">Syrian<br>Americans</h1>
    <button type="submit" class="btn btn-none" style="margin-left: 100px;">READ SERIES</button>
  </div>
  <div class="five">  
    <h3>HUMANS OF NEW YORK</h3>
    <h1 class="five5">Refugee<br>Stories</h1>
    <button type="submit" class="btn btn-none" style="margin-right: 100px;">READ SERIES</button>
  </div>
  <div class="dernier">
     <h4><svg class="badge-svg"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#badge"></use></svg></h4>
     <h1>More Humans of New York</h1>
     <icons>
      <img src="@/assets/face.png" alt="" class="images">
      <img src="@/assets/Twi.png" alt="" class="images">
      <img src="@/assets/insta.png" alt="" class="images">
     </icons>
  </div>
</div>
<div>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <button type="button" class="btn btn-none"><strong> STORIES .</strong></button>
        </li>
        <li class="nav-item">
          <button type="button" class="btn btn-none"><strong> COUNTRIES .</strong></button>
        </li>
        <li class="nav-item">
          <button type="button" class="btn btn-none"><strong> SERIES .</strong></button>
        </li>
        <li class="nav-item">
          <button type="button" class="btn btn-none"><strong> ABOUT .</strong></button>
        </li>
      </ul>
      <span class="navbar-text">
        <button type="button" class="btn btn-none"><strong> NEW YORK<br>TIMES N°1BEST<br>SELLER</strong></button>
        
      </span>
    </div>
  </div>
</nav>
</div>
</template>

<style>

.container-fluid{
  border-bottom: 1px solid;
 }
.text{
  text-align: center;
  width: 550px;
  margin-left: 500px;
  padding: 20px;
}
.first{
  background-image: url("@/assets/6.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: 25% 50%;
  padding: 100px;
  text-align: right;
  max-width: 2000px;
  height: 630px;
  font-family: 'GT Sectra Display light';
}
.first1{
  font-family: 'GT Sectra Display light';
  font-size: 100px;
  line-height: 100px;
  color: rgb(105, 52, 27)
}
.two{
  background-image: url("@/assets/2.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: 100% 50%;
  padding: 100px;
  text-align: left;
  max-width: 2000px;
  height: 740px;
  font-family: 'GT Sectra Display light';
}
.two2{
  font-family: 'GT Sectra Display light';
  font-size: 100px;
  line-height: 100px;
  color: red;
}
.free{
  background-image: url("@/assets/3.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: 25% 50%;
  padding: 100px;
  text-align: right;
  max-width: 2000px;
  height: 730px;
  font-family: 'GT Sectra Display light';
}
.free3{
  font-family: 'GT Sectra Display light';
  font-size: 100px;
  line-height: 100px;
  color: rgb(201, 231, 214);
}
.four{
  background-image: url("@/assets/4.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: 100% 50%;
  padding: 100px;
  text-align: left;
  max-width: 2000px;
  height: 700px;
  font-family: 'GT Sectra Display light';
}
.four4{
  font-family: 'GT Sectra Display light';
  font-size: 100px;
  line-height: 100px;
  color: rgb(198, 106, 31);
}
.five{
  background-image: url("@/assets/5.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: 25% 50%;
  padding: 100px;
  text-align: right;
  max-width: 2000px;
  height: 790px;
}
.five5{
  font-family: 'GT Sectra Display light';
  font-size: 100px;
  line-height: 100px;
}
.dernier{
  text-align: center;
  background-color: black;
  padding: 150px;
  color: white;
  font-family: 'GT Sectra Display';
}
.images{
height: 50px;
weight: 50px;
}

</style>
